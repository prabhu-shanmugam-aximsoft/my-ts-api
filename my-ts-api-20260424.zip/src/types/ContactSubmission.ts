export class ContactSubmission {
  id?: number;
  full_name!: string;
  email!: string;
  message!: string;
  created_at?: Date;
}